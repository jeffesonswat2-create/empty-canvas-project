import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Search, CheckCircle2, XCircle } from "lucide-react";

interface AuditoriaLog {
  id: string;
  dataHora: string;
  usuario: string;
  acao: string;
  automacao: string;
  resultado: "sucesso" | "falha";
  detalhes: string;
}

export function Auditoria() {
  const [search, setSearch] = useState("");

  const logs: AuditoriaLog[] = [
    {
      id: "aud-001",
      dataHora: "2025-11-20 15:30",
      usuario: "Agnaldo Cardoso",
      acao: "Criou automação",
      automacao: "Cobrança automática de boletos",
      resultado: "sucesso",
      detalhes: "Automação criada e publicada",
    },
    {
      id: "aud-002",
      dataHora: "2025-11-20 14:45",
      usuario: "Maria Eduarda",
      acao: "Editou automação",
      automacao: "Follow-up pós-venda",
      resultado: "sucesso",
      detalhes: "Atualizado template de e-mail",
    },
    {
      id: "aud-003",
      dataHora: "2025-11-20 13:20",
      usuario: "Agnaldo Cardoso",
      acao: "Desativou automação",
      automacao: "Reprocessar rejeições fiscais",
      resultado: "sucesso",
      detalhes: "Automação desativada temporariamente",
    },
    {
      id: "aud-004",
      dataHora: "2025-11-20 12:10",
      usuario: "João Silva",
      acao: "Tentou excluir automação",
      automacao: "Qualificar lead",
      resultado: "falha",
      detalhes: "Permissão negada: apenas admin pode excluir",
    },
    {
      id: "aud-005",
      dataHora: "2025-11-20 11:30",
      usuario: "Maria Eduarda",
      acao: "Clonou automação",
      automacao: "Alerta de expiração de consignação",
      resultado: "sucesso",
      detalhes: "Nova automação criada a partir do template",
    },
    {
      id: "aud-006",
      dataHora: "2025-11-20 10:15",
      usuario: "Agnaldo Cardoso",
      acao: "Ativou automação",
      automacao: "Relatório diário de KPIs",
      resultado: "sucesso",
      detalhes: "Automação ativada e agendamento configurado",
    },
    {
      id: "aud-007",
      dataHora: "2025-11-20 09:45",
      usuario: "João Silva",
      acao: "Testou automação",
      automacao: "Cobrança automática de boletos",
      resultado: "sucesso",
      detalhes: "Teste executado com sucesso (modo sandbox)",
    },
    {
      id: "aud-008",
      dataHora: "2025-11-20 09:00",
      usuario: "Maria Eduarda",
      acao: "Exportou automação",
      automacao: "Follow-up pós-venda",
      resultado: "sucesso",
      detalhes: "Arquivo JSON baixado",
    },
  ];

  const filteredLogs = logs.filter(
    (log) =>
      log.usuario.toLowerCase().includes(search.toLowerCase()) ||
      log.acao.toLowerCase().includes(search.toLowerCase()) ||
      log.automacao.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Busca */}
      <Card className="bg-card border-border">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por usuário, ação ou automação..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Tabela de auditoria */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Histórico de Ações</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data/Hora</TableHead>
                <TableHead>Usuário</TableHead>
                <TableHead>Ação</TableHead>
                <TableHead>Automação</TableHead>
                <TableHead>Detalhes</TableHead>
                <TableHead>Resultado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell className="font-mono text-sm">
                    {log.dataHora}
                  </TableCell>
                  <TableCell>{log.usuario}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{log.acao}</Badge>
                  </TableCell>
                  <TableCell className="max-w-[200px] truncate">
                    {log.automacao}
                  </TableCell>
                  <TableCell className="max-w-[250px] truncate text-muted-foreground text-sm">
                    {log.detalhes}
                  </TableCell>
                  <TableCell>
                    {log.resultado === "sucesso" ? (
                      <Badge
                        variant="default"
                        className="bg-green-500/10 text-green-500 hover:bg-green-500/20"
                      >
                        <CheckCircle2 className="w-3 h-3 mr-1" />
                        Sucesso
                      </Badge>
                    ) : (
                      <Badge
                        variant="default"
                        className="bg-red-500/10 text-red-500 hover:bg-red-500/20"
                      >
                        <XCircle className="w-3 h-3 mr-1" />
                        Falha
                      </Badge>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredLogs.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              Nenhum registro encontrado
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
