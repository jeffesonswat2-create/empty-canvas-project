import { Card, CardContent } from "@/components/ui/card";
import { Building2, TrendingUp, DollarSign, FileText, ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const RelatorioVendas = () => {
  return (
    <div className="min-h-screen bg-background p-6 space-y-6">
      {/* Header */}
      <div className="space-y-4 mb-6">
        <div className="flex items-start gap-3">
          <TrendingUp className="h-8 w-8 text-primary mt-1" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">Relatório de Vendas</h1>
            <p className="text-muted-foreground mt-1">
              Análises e Faturamento — Todas as vendas, filtros por período, vendedor, produto e formas de pagamento
            </p>
          </div>
        </div>

        {/* Company Info Card */}
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex items-center gap-3">
                <Building2 className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">Empresa</p>
                  <p className="font-semibold text-white">LR Distribuidora de Livros e Revistas LTDA</p>
                </div>
              </div>
              <div className="flex items-center gap-2 sm:ml-auto">
                <p className="text-xs text-muted-foreground">CNPJ:</p>
                <p className="font-semibold text-white">12.345.678/0001-90</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Faturamento Total</p>
                <p className="text-2xl font-bold text-white mt-1">R$ 124.500,00</p>
              </div>
              <DollarSign className="h-10 w-10 text-primary opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total de Vendas</p>
                <p className="text-2xl font-bold text-white mt-1">1.245</p>
              </div>
              <ShoppingCart className="h-10 w-10 text-primary opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Ticket Médio</p>
                <p className="text-2xl font-bold text-white mt-1">R$ 99,92</p>
              </div>
              <FileText className="h-10 w-10 text-primary opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Crescimento</p>
                <p className="text-2xl font-bold text-green-500 mt-1">+12,5%</p>
              </div>
              <TrendingUp className="h-10 w-10 text-green-500 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Filtros</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Data Inicial</label>
              <Input type="date" className="bg-background border-border text-white" />
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Data Final</label>
              <Input type="date" className="bg-background border-border text-white" />
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Vendedor</label>
              <Select>
                <SelectTrigger className="bg-background border-border text-white">
                  <SelectValue placeholder="Todos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  <SelectItem value="vendedor1">João Silva</SelectItem>
                  <SelectItem value="vendedor2">Maria Santos</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Forma de Pagamento</label>
              <Select>
                <SelectTrigger className="bg-background border-border text-white">
                  <SelectValue placeholder="Todas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas</SelectItem>
                  <SelectItem value="dinheiro">Dinheiro</SelectItem>
                  <SelectItem value="cartao">Cartão</SelectItem>
                  <SelectItem value="pix">PIX</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <Button className="bg-primary text-white hover:bg-primary/90">Aplicar Filtros</Button>
            <Button variant="outline" className="border-border text-white">Limpar</Button>
            <Button variant="outline" className="border-border text-white ml-auto">Exportar PDF</Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabela */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Vendas Realizadas</h3>
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="text-muted-foreground">Data</TableHead>
                <TableHead className="text-muted-foreground">Nota Fiscal</TableHead>
                <TableHead className="text-muted-foreground">Cliente</TableHead>
                <TableHead className="text-muted-foreground">Vendedor</TableHead>
                <TableHead className="text-muted-foreground">Forma Pgto</TableHead>
                <TableHead className="text-muted-foreground text-right">Valor</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[1, 2, 3, 4, 5].map((i) => (
                <TableRow key={i} className="border-border">
                  <TableCell className="text-white">15/01/2025</TableCell>
                  <TableCell className="text-white">NF-{12340 + i}</TableCell>
                  <TableCell className="text-white">Cliente Exemplo {i}</TableCell>
                  <TableCell className="text-white">João Silva</TableCell>
                  <TableCell className="text-white">PIX</TableCell>
                  <TableCell className="text-white text-right">R$ 1.250,00</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default RelatorioVendas;
