import { Card, CardContent } from "@/components/ui/card";
import { Building2, Package, TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const RelatorioEstoque = () => {
  return (
    <div className="min-h-screen bg-background p-6 space-y-6">
      {/* Header */}
      <div className="space-y-4 mb-6">
        <div className="flex items-start gap-3">
          <Package className="h-8 w-8 text-primary mt-1" />
          <div>
            <h1 className="text-3xl font-bold text-foreground">Relatório de Estoque</h1>
            <p className="text-muted-foreground mt-1">
              Movimentação e Saldo — Entradas, saídas, ajustes, inventário e produtos com estoque baixo
            </p>
          </div>
        </div>

        {/* Company Info Card */}
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex items-center gap-3">
                <Building2 className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-xs text-muted-foreground">Empresa</p>
                  <p className="font-semibold text-white">LR Distribuidora de Livros e Revistas LTDA</p>
                </div>
              </div>
              <div className="flex items-center gap-2 sm:ml-auto">
                <p className="text-xs text-muted-foreground">CNPJ:</p>
                <p className="font-semibold text-white">12.345.678/0001-90</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total de Produtos</p>
                <p className="text-2xl font-bold text-white mt-1">3.458</p>
              </div>
              <Package className="h-10 w-10 text-primary opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Entradas (mês)</p>
                <p className="text-2xl font-bold text-green-500 mt-1">+1.245</p>
              </div>
              <TrendingUp className="h-10 w-10 text-green-500 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Saídas (mês)</p>
                <p className="text-2xl font-bold text-red-500 mt-1">-892</p>
              </div>
              <TrendingDown className="h-10 w-10 text-red-500 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Estoque Baixo</p>
                <p className="text-2xl font-bold text-yellow-500 mt-1">45</p>
              </div>
              <AlertTriangle className="h-10 w-10 text-yellow-500 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Filtros</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Data Inicial</label>
              <Input type="date" className="bg-background border-border text-white" />
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Data Final</label>
              <Input type="date" className="bg-background border-border text-white" />
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Tipo de Movimentação</label>
              <Select>
                <SelectTrigger className="bg-background border-border text-white">
                  <SelectValue placeholder="Todas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas</SelectItem>
                  <SelectItem value="entrada">Entrada</SelectItem>
                  <SelectItem value="saida">Saída</SelectItem>
                  <SelectItem value="ajuste">Ajuste</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-muted-foreground mb-2 block">Buscar Produto</label>
              <Input 
                type="text" 
                placeholder="Código ou nome" 
                className="bg-background border-border text-white" 
              />
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <Button className="bg-primary text-white hover:bg-primary/90">Aplicar Filtros</Button>
            <Button variant="outline" className="border-border text-white">Limpar</Button>
            <Button variant="outline" className="border-border text-white ml-auto">Exportar PDF</Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabela */}
      <Card className="bg-card border-border">
        <CardContent className="p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Movimentação de Estoque</h3>
          <Table>
            <TableHeader>
              <TableRow className="border-border">
                <TableHead className="text-muted-foreground">Data</TableHead>
                <TableHead className="text-muted-foreground">Tipo</TableHead>
                <TableHead className="text-muted-foreground">Produto</TableHead>
                <TableHead className="text-muted-foreground">Quantidade</TableHead>
                <TableHead className="text-muted-foreground">Saldo</TableHead>
                <TableHead className="text-muted-foreground">Documento</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[1, 2, 3, 4, 5].map((i) => (
                <TableRow key={i} className="border-border">
                  <TableCell className="text-white">15/01/2025</TableCell>
                  <TableCell className="text-white">
                    <span className="px-2 py-1 rounded text-xs bg-green-500/20 text-green-500">
                      Entrada
                    </span>
                  </TableCell>
                  <TableCell className="text-white">Produto Exemplo {i}</TableCell>
                  <TableCell className="text-white">+50</TableCell>
                  <TableCell className="text-white">350</TableCell>
                  <TableCell className="text-white">NF-12345</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default RelatorioEstoque;
