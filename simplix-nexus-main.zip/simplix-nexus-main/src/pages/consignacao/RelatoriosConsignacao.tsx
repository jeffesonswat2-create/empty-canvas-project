import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { FileText, Download, Printer, Users, Package, DollarSign, RotateCcw, CheckCircle } from "lucide-react";
import { toast } from "sonner";

const RelatoriosConsignacao = () => {
  const handleGerarRelatorio = (tipo: string) => {
    toast.success(`Gerando relatório: ${tipo}`);
  };

  return (
    <div className="flex-1 flex flex-col w-full">
      <main className="flex-1 p-6 space-y-6 overflow-auto" style={{ backgroundColor: '#0F1115' }}>
        <div>
          <h1 className="text-3xl font-bold" style={{ color: '#3BA3FF' }}>
            Relatórios de Consignação
          </h1>
          <p className="text-sm mt-1" style={{ color: '#8EA0B5' }}>
            Gere relatórios detalhados em PDF de consignação, envios, devoluções, acertos e histórico
          </p>
        </div>

        {/* Filtros Globais */}
        <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <CardHeader>
            <CardTitle style={{ color: '#E7EEF6' }}>Filtros para Relatórios</CardTitle>
            <CardDescription style={{ color: '#8EA0B5' }}>
              Configure os filtros que serão aplicados aos relatórios
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Data Inicial</Label>
                <Input
                  type="date"
                  style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}
                />
              </div>

              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Data Final</Label>
                <Input
                  type="date"
                  style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}
                />
              </div>

              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Cliente (opcional)</Label>
                <Select>
                  <SelectTrigger style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}>
                    <SelectValue placeholder="Todos os clientes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos</SelectItem>
                    <SelectItem value="livraria-central">Livraria Central LTDA</SelectItem>
                    <SelectItem value="papelaria-sp">Papelaria São Paulo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tipos de Relatórios */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Relatório de Consignação — Resumo Geral */}
          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader>
              <div className="flex items-center gap-3">
                <FileText className="h-6 w-6" style={{ color: '#3BA3FF' }} />
                <div>
                  <CardTitle style={{ color: '#E7EEF6' }}>Relatório de Consignação</CardTitle>
                  <CardDescription style={{ color: '#8EA0B5' }}>
                    Resumo Geral
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm" style={{ color: '#8EA0B5' }}>
                Resumo dos consignados, vendas em consignação e status dos consignatários.
              </p>
              <div className="flex gap-2">
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  onClick={() => handleGerarRelatorio("Consignação — Resumo Geral")}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Gerar PDF
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => toast.info("Imprimindo...")}
                >
                  <Printer className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Relatório de Estoque Consignado — Produtos com Terceiros */}
          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Package className="h-6 w-6" style={{ color: '#3BA3FF' }} />
                <div>
                  <CardTitle style={{ color: '#E7EEF6' }}>Relatório de Estoque Consignado</CardTitle>
                  <CardDescription style={{ color: '#8EA0B5' }}>
                    Produtos com Terceiros
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm" style={{ color: '#8EA0B5' }}>
                Lista de produtos enviados e saldo total por consignatário.
              </p>
              <div className="flex gap-2">
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  onClick={() => handleGerarRelatorio("Estoque Consignado — Produtos com Terceiros")}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Gerar PDF
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => toast.info("Imprimindo...")}
                >
                  <Printer className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Relatório de Envio — Itens Enviados */}
          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Package className="h-6 w-6" style={{ color: '#3BA3FF' }} />
                <div>
                  <CardTitle style={{ color: '#E7EEF6' }}>Relatório de Envio</CardTitle>
                  <CardDescription style={{ color: '#8EA0B5' }}>
                    Itens Enviados
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm" style={{ color: '#8EA0B5' }}>
                Todos os produtos enviados para consignação.
              </p>
              <div className="flex gap-2">
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  onClick={() => handleGerarRelatorio("Envio — Itens Enviados")}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Gerar PDF
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => toast.info("Imprimindo...")}
                >
                  <Printer className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Relatório de Devoluções — Itens Retornados */}
          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader>
              <div className="flex items-center gap-3">
                <RotateCcw className="h-6 w-6" style={{ color: '#3BA3FF' }} />
                <div>
                  <CardTitle style={{ color: '#E7EEF6' }}>Relatório de Devoluções</CardTitle>
                  <CardDescription style={{ color: '#8EA0B5' }}>
                    Itens Retornados
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm" style={{ color: '#8EA0B5' }}>
                Itens devolvidos pelos consignatários (totais e parciais).
              </p>
              <div className="flex gap-2">
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  onClick={() => handleGerarRelatorio("Devoluções — Itens Retornados")}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Gerar PDF
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => toast.info("Imprimindo...")}
                >
                  <Printer className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Relatório de Acertos — Fechamentos Financeiros */}
          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader>
              <div className="flex items-center gap-3">
                <CheckCircle className="h-6 w-6" style={{ color: '#3BA3FF' }} />
                <div>
                  <CardTitle style={{ color: '#E7EEF6' }}>Relatório de Acertos</CardTitle>
                  <CardDescription style={{ color: '#8EA0B5' }}>
                    Fechamentos Financeiros
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm" style={{ color: '#8EA0B5' }}>
                Valores vendidos, devolvidos, pagos e pendentes.
              </p>
              <div className="flex gap-2">
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  onClick={() => handleGerarRelatorio("Acertos — Fechamentos Financeiros")}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Gerar PDF
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => toast.info("Imprimindo...")}
                >
                  <Printer className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Relatório de Histórico — Linha do Tempo Completa */}
          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader>
              <div className="flex items-center gap-3">
                <FileText className="h-6 w-6" style={{ color: '#3BA3FF' }} />
                <div>
                  <CardTitle style={{ color: '#E7EEF6' }}>Relatório de Histórico</CardTitle>
                  <CardDescription style={{ color: '#8EA0B5' }}>
                    Linha do Tempo Completa
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm" style={{ color: '#8EA0B5' }}>
                Eventos cronológicos da consignação (envios, retornos, acertos, ajustes).
              </p>
              <div className="flex gap-2">
                <Button 
                  className="flex-1 bg-primary hover:bg-primary/90"
                  onClick={() => handleGerarRelatorio("Histórico — Linha do Tempo Completa")}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Gerar PDF
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => toast.info("Imprimindo...")}
                >
                  <Printer className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Ações em Lote */}
        <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <CardHeader>
            <CardTitle style={{ color: '#E7EEF6' }}>Ações em Lote</CardTitle>
            <CardDescription style={{ color: '#8EA0B5' }}>
              Gere múltiplos relatórios de uma vez
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-3">
              <Button 
                onClick={() => toast.success("Gerando todos os relatórios...")}
                className="bg-primary hover:bg-primary/90"
              >
                <Download className="h-4 w-4 mr-2" />
                Gerar Todos os Relatórios
              </Button>
              <Button 
                variant="outline"
                onClick={() => toast.info("Enviando relatórios por e-mail...")}
              >
                Enviar por E-mail
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default RelatoriosConsignacao;