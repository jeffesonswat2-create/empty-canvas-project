import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, Eye } from "lucide-react";
import { toast } from "sonner";

interface Movimentacao {
  id: string;
  tipo: "envio" | "devolucao" | "acerto";
  cliente: string;
  produto: string;
  quantidade: number;
  valor: string;
  status: string;
  usuario: string;
  data: string;
}

const HistoricoConsignacao = () => {
  const [historico] = useState<Movimentacao[]>([
    {
      id: "1",
      tipo: "envio",
      cliente: "Livraria Central LTDA",
      produto: "Livro Educativo Vol. 1",
      quantidade: 100,
      valor: "R$ 3.500,00",
      status: "Concluído",
      usuario: "Admin",
      data: "2025-01-15"
    },
    {
      id: "2",
      tipo: "devolucao",
      cliente: "Papelaria São Paulo",
      produto: "Caderno Universitário",
      quantidade: 35,
      valor: "R$ 875,00",
      status: "Processado",
      usuario: "Gerente",
      data: "2025-01-18"
    },
    {
      id: "3",
      tipo: "acerto",
      cliente: "Distribuidora ABC",
      produto: "Kit Material Escolar",
      quantidade: 50,
      valor: "R$ 2.250,00",
      status: "Concluído",
      usuario: "Admin",
      data: "2025-01-20"
    }
  ]);

  const getTipoBadge = (tipo: string) => {
    const variants: Record<string, { className: string; label: string }> = {
      "envio": { className: "bg-primary/20 text-primary hover:bg-primary/30", label: "Envio" },
      "devolucao": { className: "bg-warning/20 text-warning hover:bg-warning/30", label: "Devolução" },
      "acerto": { className: "bg-success/20 text-success hover:bg-success/30", label: "Acerto" }
    };

    const config = variants[tipo] || variants["envio"];
    
    return (
      <Badge variant="outline" className={config.className}>
        {config.label}
      </Badge>
    );
  };

  return (
    <div className="flex-1 flex flex-col w-full">
      <main className="flex-1 p-6 space-y-6 overflow-auto" style={{ backgroundColor: '#0F1115' }}>
        <div>
          <h1 className="text-3xl font-bold" style={{ color: '#3BA3FF' }}>
            Histórico de Movimentações
          </h1>
          <p className="text-sm mt-1" style={{ color: '#8EA0B5' }}>
            Visualize todas as movimentações de consignação
          </p>
        </div>

        {/* Filtros */}
        <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <CardHeader>
            <CardTitle style={{ color: '#E7EEF6' }}>Filtros</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Cliente</Label>
                <Select>
                  <SelectTrigger style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}>
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos</SelectItem>
                    <SelectItem value="livraria-central">Livraria Central LTDA</SelectItem>
                    <SelectItem value="papelaria-sp">Papelaria São Paulo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Tipo</Label>
                <Select>
                  <SelectTrigger style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}>
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos</SelectItem>
                    <SelectItem value="envio">Envio</SelectItem>
                    <SelectItem value="devolucao">Devolução</SelectItem>
                    <SelectItem value="acerto">Acerto</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Data Inicial</Label>
                <Input
                  type="date"
                  style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}
                />
              </div>

              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Data Final</Label>
                <Input
                  type="date"
                  style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button>Aplicar filtros</Button>
              <Button variant="outline">Limpar</Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabela */}
        <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <CardHeader>
            <CardTitle style={{ color: '#E7EEF6' }}>Movimentações</CardTitle>
            <CardDescription style={{ color: '#8EA0B5' }}>
              {historico.length} movimentações encontradas
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow style={{ borderColor: '#20283A' }}>
                    <TableHead style={{ color: '#8EA0B5' }}>Tipo</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Cliente</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Produto</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Quantidade</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Valor</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Status</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Usuário</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Data</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {historico.map((item) => (
                    <TableRow key={item.id} style={{ borderColor: '#20283A' }}>
                      <TableCell>{getTipoBadge(item.tipo)}</TableCell>
                      <TableCell style={{ color: '#E7EEF6' }}>{item.cliente}</TableCell>
                      <TableCell style={{ color: '#E7EEF6' }}>{item.produto}</TableCell>
                      <TableCell style={{ color: '#3BA3FF' }}>{item.quantidade}</TableCell>
                      <TableCell style={{ color: '#E7EEF6' }}>{item.valor}</TableCell>
                      <TableCell style={{ color: '#8EA0B5' }}>{item.status}</TableCell>
                      <TableCell style={{ color: '#8EA0B5' }}>{item.usuario}</TableCell>
                      <TableCell style={{ color: '#8EA0B5' }}>{new Date(item.data).toLocaleDateString('pt-BR')}</TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0"
                          onClick={() => toast.info("Visualizando detalhes...")}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default HistoricoConsignacao;