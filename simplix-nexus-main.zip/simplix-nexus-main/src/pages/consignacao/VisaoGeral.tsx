import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, Users, DollarSign, RotateCcw, CheckCircle } from "lucide-react";

const VisaoGeral = () => {
  return (
    <div className="flex-1 flex flex-col w-full">
      <main className="flex-1 p-6 space-y-6 overflow-auto" style={{ backgroundColor: '#0F1115' }}>
        {/* Título */}
        <div>
          <h1 className="text-3xl font-bold" style={{ color: '#3BA3FF' }}>
            Consignação — Visão Geral
          </h1>
          <p className="text-sm mt-1" style={{ color: '#8EA0B5' }}>
            Acompanhe o status geral das consignações
          </p>
        </div>

        {/* Card da Empresa */}
        <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold" style={{ color: '#E7EEF6' }}>
                  LR Distribuidora de Livros e Revistas LTDA
                </h3>
                <p className="text-sm" style={{ color: '#8EA0B5' }}>
                  CNPJ: 12.345.678/0001-90
                </p>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: '#22C55E' }} />
                <span className="text-sm" style={{ color: '#8EA0B5' }}>Sistema Online</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Cards Principais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader className="pb-3">
              <CardDescription style={{ color: '#8EA0B5' }} className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                Clientes ativos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" style={{ color: '#3BA3FF' }}>48</div>
            </CardContent>
          </Card>

          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader className="pb-3">
              <CardDescription style={{ color: '#8EA0B5' }} className="flex items-center gap-2">
                <Package className="h-4 w-4" />
                Produtos consignados
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" style={{ color: '#3BA3FF' }}>1.245</div>
            </CardContent>
          </Card>

          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader className="pb-3">
              <CardDescription style={{ color: '#8EA0B5' }} className="flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                Total consignado
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" style={{ color: '#22C55E' }}>R$ 48.750,00</div>
            </CardContent>
          </Card>

          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader className="pb-3">
              <CardDescription style={{ color: '#8EA0B5' }} className="flex items-center gap-2">
                <RotateCcw className="h-4 w-4" />
                Devoluções pendentes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" style={{ color: '#F59E0B' }}>12</div>
            </CardContent>
          </Card>

          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader className="pb-3">
              <CardDescription style={{ color: '#8EA0B5' }} className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4" />
                Acertos pendentes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" style={{ color: '#F59E0B' }}>8</div>
            </CardContent>
          </Card>
        </div>

        {/* Resumo por Status */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader>
              <CardTitle style={{ color: '#E7EEF6' }}>Top 5 Clientes</CardTitle>
              <CardDescription style={{ color: '#8EA0B5' }}>
                Clientes com maior volume consignado
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { nome: "Livraria Central LTDA", valor: "R$ 12.500,00", itens: 320 },
                  { nome: "Papelaria São Paulo", valor: "R$ 8.750,00", itens: 245 },
                  { nome: "Distribuidora ABC", valor: "R$ 7.200,00", itens: 198 },
                  { nome: "Livraria Moderna", valor: "R$ 6.450,00", itens: 175 },
                  { nome: "Mega Livros", valor: "R$ 5.890,00", itens: 156 }
                ].map((cliente, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg" style={{ backgroundColor: '#0F1115' }}>
                    <div>
                      <p className="font-medium" style={{ color: '#E7EEF6' }}>{cliente.nome}</p>
                      <p className="text-sm" style={{ color: '#8EA0B5' }}>{cliente.itens} itens</p>
                    </div>
                    <div className="font-bold" style={{ color: '#3BA3FF' }}>{cliente.valor}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader>
              <CardTitle style={{ color: '#E7EEF6' }}>Produtos Mais Consignados</CardTitle>
              <CardDescription style={{ color: '#8EA0B5' }}>
                Produtos com maior movimentação
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { nome: "Livro Educativo Vol. 1", qtd: 450, valor: "R$ 15.750,00" },
                  { nome: "Caderno Universitário", qtd: 380, valor: "R$ 9.500,00" },
                  { nome: "Kit Material Escolar", qtd: 295, valor: "R$ 8.850,00" },
                  { nome: "Livro Didático Matemática", qtd: 220, valor: "R$ 7.920,00" },
                  { nome: "Revista Mensal Assinatura", qtd: 180, valor: "R$ 3.240,00" }
                ].map((produto, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg" style={{ backgroundColor: '#0F1115' }}>
                    <div>
                      <p className="font-medium" style={{ color: '#E7EEF6' }}>{produto.nome}</p>
                      <p className="text-sm" style={{ color: '#8EA0B5' }}>{produto.qtd} unidades</p>
                    </div>
                    <div className="font-bold" style={{ color: '#3BA3FF' }}>{produto.valor}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default VisaoGeral;