import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Eye, RotateCcw, CheckCircle, Search } from "lucide-react";
import { toast } from "sonner";

interface EstoqueItem {
  id: string;
  codigo: string;
  produto: string;
  cliente: string;
  qtdEnviada: number;
  qtdDevolvida: number;
  qtdPoderCliente: number;
  validade: string;
  status: "ativo" | "pendente" | "encerrado";
}

const EstoqueConsignado = () => {
  const [estoque] = useState<EstoqueItem[]>([
    {
      id: "1",
      codigo: "PRD001",
      produto: "Livro Educativo Vol. 1",
      cliente: "Livraria Central LTDA",
      qtdEnviada: 100,
      qtdDevolvida: 20,
      qtdPoderCliente: 80,
      validade: "31/12/2025",
      status: "ativo"
    },
    {
      id: "2",
      codigo: "PRD002",
      produto: "Caderno Universitário",
      cliente: "Papelaria São Paulo",
      qtdEnviada: 150,
      qtdDevolvida: 0,
      qtdPoderCliente: 150,
      validade: "30/06/2025",
      status: "ativo"
    },
    {
      id: "3",
      codigo: "PRD003",
      produto: "Kit Material Escolar",
      cliente: "Distribuidora ABC",
      qtdEnviada: 80,
      qtdDevolvida: 80,
      qtdPoderCliente: 0,
      validade: "15/08/2025",
      status: "encerrado"
    }
  ]);

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { className: string; label: string }> = {
      "ativo": { className: "bg-success/20 text-success hover:bg-success/30", label: "Ativo" },
      "pendente": { className: "bg-warning/20 text-warning hover:bg-warning/30", label: "Pendente" },
      "encerrado": { className: "bg-muted/50 text-muted-foreground hover:bg-muted/70", label: "Encerrado" }
    };

    const config = variants[status] || variants["pendente"];
    
    return (
      <Badge variant="outline" className={config.className}>
        {config.label}
      </Badge>
    );
  };

  return (
    <div className="flex-1 flex flex-col w-full">
      <main className="flex-1 p-6 space-y-6 overflow-auto" style={{ backgroundColor: '#0F1115' }}>
        <div>
          <h1 className="text-3xl font-bold" style={{ color: '#3BA3FF' }}>
            Estoque Consignado
          </h1>
          <p className="text-sm mt-1" style={{ color: '#8EA0B5' }}>
            Visualize todos os produtos em consignação
          </p>
        </div>

        {/* Filtros */}
        <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <CardHeader>
            <CardTitle style={{ color: '#E7EEF6' }}>Filtros</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Cliente</Label>
                <Select>
                  <SelectTrigger style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}>
                    <SelectValue placeholder="Todos os clientes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos</SelectItem>
                    <SelectItem value="livraria-central">Livraria Central LTDA</SelectItem>
                    <SelectItem value="papelaria-sp">Papelaria São Paulo</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Produto</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4" style={{ color: '#8EA0B5' }} />
                  <Input
                    placeholder="Buscar produto..."
                    className="pl-10"
                    style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Status</Label>
                <Select>
                  <SelectTrigger style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}>
                    <SelectValue placeholder="Todos os status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos</SelectItem>
                    <SelectItem value="ativo">Ativo</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="encerrado">Encerrado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2">
              <Button>Aplicar filtros</Button>
              <Button variant="outline">Limpar</Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabela */}
        <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <CardHeader>
            <CardTitle style={{ color: '#E7EEF6' }}>Produtos em Consignação</CardTitle>
            <CardDescription style={{ color: '#8EA0B5' }}>
              {estoque.length} produtos encontrados
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow style={{ borderColor: '#20283A' }}>
                    <TableHead style={{ color: '#8EA0B5' }}>Código</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Produto</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Cliente</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Qtd Enviada</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Qtd Devolvida</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Qtd em Poder</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Validade</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Status</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {estoque.map((item) => (
                    <TableRow key={item.id} style={{ borderColor: '#20283A' }}>
                      <TableCell style={{ color: '#E7EEF6' }} className="font-mono">{item.codigo}</TableCell>
                      <TableCell style={{ color: '#E7EEF6' }}>{item.produto}</TableCell>
                      <TableCell style={{ color: '#E7EEF6' }}>{item.cliente}</TableCell>
                      <TableCell style={{ color: '#E7EEF6' }}>{item.qtdEnviada}</TableCell>
                      <TableCell style={{ color: '#E7EEF6' }}>{item.qtdDevolvida}</TableCell>
                      <TableCell style={{ color: '#3BA3FF' }} className="font-semibold">{item.qtdPoderCliente}</TableCell>
                      <TableCell style={{ color: '#8EA0B5' }}>{item.validade}</TableCell>
                      <TableCell>{getStatusBadge(item.status)}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => toast.info("Visualizando detalhes...")}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => toast.info("Registrando devolução...")}
                          >
                            <RotateCcw className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => toast.info("Registrando acerto...")}
                          >
                            <CheckCircle className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default EstoqueConsignado;