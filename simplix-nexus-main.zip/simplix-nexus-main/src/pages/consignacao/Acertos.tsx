import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DollarSign, Package, TrendingUp, CheckCircle, Plus, Download } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";

const Acertos = () => {
  const [modalPagamento, setModalPagamento] = useState(false);
  const [modalFechar, setModalFechar] = useState(false);

  return (
    <div className="flex-1 flex flex-col w-full">
      <main className="flex-1 p-6 space-y-6 overflow-auto" style={{ backgroundColor: '#0F1115' }}>
        <div>
          <h1 className="text-3xl font-bold" style={{ color: '#3BA3FF' }}>
            Acertos Financeiros
          </h1>
          <p className="text-sm mt-1" style={{ color: '#8EA0B5' }}>
            Gerencie acertos de consignação com clientes
          </p>
        </div>

        {/* Cards Principais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader className="pb-3">
              <CardDescription style={{ color: '#8EA0B5' }} className="flex items-center gap-2">
                <DollarSign className="h-4 w-4" />
                Total Devido
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" style={{ color: '#F59E0B' }}>R$ 25.840,00</div>
            </CardContent>
          </Card>

          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader className="pb-3">
              <CardDescription style={{ color: '#8EA0B5' }} className="flex items-center gap-2">
                <Package className="h-4 w-4" />
                Total Devolvido
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" style={{ color: '#EF4444' }}>R$ 12.450,00</div>
            </CardContent>
          </Card>

          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader className="pb-3">
              <CardDescription style={{ color: '#8EA0B5' }} className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Total Vendido
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" style={{ color: '#22C55E' }}>R$ 36.300,00</div>
            </CardContent>
          </Card>

          <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
            <CardHeader className="pb-3">
              <CardDescription style={{ color: '#8EA0B5' }} className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4" />
                Total Acertado
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" style={{ color: '#3BA3FF' }}>R$ 22.910,00</div>
            </CardContent>
          </Card>
        </div>

        {/* Ações Rápidas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button onClick={() => setModalPagamento(true)} className="h-24 bg-primary hover:bg-primary/90">
            <div className="flex flex-col items-center gap-2">
              <Plus className="h-6 w-6" />
              <span>Registrar Pagamento</span>
            </div>
          </Button>

          <Button onClick={() => setModalFechar(true)} variant="outline" className="h-24">
            <div className="flex flex-col items-center gap-2">
              <CheckCircle className="h-6 w-6" />
              <span>Fechar Consignação</span>
            </div>
          </Button>

          <Button variant="outline" className="h-24" onClick={() => toast.info("Gerando comprovante...")}>
            <div className="flex flex-col items-center gap-2">
              <Download className="h-6 w-6" />
              <span>Exportar Comprovante</span>
            </div>
          </Button>
        </div>

        {/* Detalhamento por Cliente */}
        <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <CardHeader>
            <CardTitle style={{ color: '#E7EEF6' }}>Acertos Pendentes por Cliente</CardTitle>
            <CardDescription style={{ color: '#8EA0B5' }}>
              Clientes com acertos em aberto
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { cliente: "Livraria Central LTDA", vendido: "R$ 12.500,00", devolvido: "R$ 3.200,00", devido: "R$ 9.300,00" },
                { cliente: "Papelaria São Paulo", vendido: "R$ 8.750,00", devolvido: "R$ 2.150,00", devido: "R$ 6.600,00" },
                { cliente: "Distribuidora ABC", vendido: "R$ 7.200,00", devolvido: "R$ 4.100,00", devido: "R$ 3.100,00" },
                { cliente: "Livraria Moderna", vendido: "R$ 5.450,00", devolvido: "R$ 1.800,00", devido: "R$ 3.650,00" },
                { cliente: "Mega Livros", vendido: "R$ 2.400,00", devolvido: "R$ 1.200,00", devido: "R$ 1.200,00" }
              ].map((item, index) => (
                <div key={index} className="p-4 rounded-lg" style={{ backgroundColor: '#0F1115' }}>
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold" style={{ color: '#E7EEF6' }}>{item.cliente}</h4>
                    <Button size="sm" onClick={() => setModalPagamento(true)}>Registrar Pagamento</Button>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p style={{ color: '#8EA0B5' }}>Vendido</p>
                      <p className="font-semibold" style={{ color: '#22C55E' }}>{item.vendido}</p>
                    </div>
                    <div>
                      <p style={{ color: '#8EA0B5' }}>Devolvido</p>
                      <p className="font-semibold" style={{ color: '#EF4444' }}>{item.devolvido}</p>
                    </div>
                    <div>
                      <p style={{ color: '#8EA0B5' }}>Devido</p>
                      <p className="font-semibold" style={{ color: '#F59E0B' }}>{item.devido}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Modal Registrar Pagamento */}
      <Dialog open={modalPagamento} onOpenChange={setModalPagamento}>
        <DialogContent style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <DialogHeader>
            <DialogTitle style={{ color: '#E7EEF6' }}>Registrar Pagamento</DialogTitle>
            <DialogDescription style={{ color: '#8EA0B5' }}>
              Informe os dados do pagamento recebido
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label style={{ color: '#E7EEF6' }}>Cliente</Label>
              <Select>
                <SelectTrigger style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}>
                  <SelectValue placeholder="Selecione o cliente" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="livraria-central">Livraria Central LTDA</SelectItem>
                  <SelectItem value="papelaria-sp">Papelaria São Paulo</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label style={{ color: '#E7EEF6' }}>Valor do Pagamento</Label>
              <Input
                type="text"
                placeholder="R$ 0,00"
                style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}
              />
            </div>

            <div className="space-y-2">
              <Label style={{ color: '#E7EEF6' }}>Forma de Pagamento</Label>
              <Select>
                <SelectTrigger style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dinheiro">Dinheiro</SelectItem>
                  <SelectItem value="pix">PIX</SelectItem>
                  <SelectItem value="transferencia">Transferência</SelectItem>
                  <SelectItem value="cheque">Cheque</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label style={{ color: '#E7EEF6' }}>Data do Pagamento</Label>
              <Input
                type="date"
                style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setModalPagamento(false)}>
              Cancelar
            </Button>
            <Button onClick={() => {
              toast.success("Pagamento registrado com sucesso");
              setModalPagamento(false);
            }} className="bg-primary hover:bg-primary/90">
              Confirmar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal Fechar Consignação */}
      <Dialog open={modalFechar} onOpenChange={setModalFechar}>
        <DialogContent style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <DialogHeader>
            <DialogTitle style={{ color: '#E7EEF6' }}>Fechar Consignação</DialogTitle>
            <DialogDescription style={{ color: '#8EA0B5' }}>
              Encerrar o processo de consignação com o cliente
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label style={{ color: '#E7EEF6' }}>Cliente</Label>
              <Select>
                <SelectTrigger style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}>
                  <SelectValue placeholder="Selecione o cliente" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="livraria-central">Livraria Central LTDA</SelectItem>
                  <SelectItem value="papelaria-sp">Papelaria São Paulo</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="p-4 rounded-lg space-y-2" style={{ backgroundColor: '#0F1115' }}>
              <div className="flex justify-between">
                <span style={{ color: '#8EA0B5' }}>Total Vendido:</span>
                <span className="font-semibold" style={{ color: '#22C55E' }}>R$ 12.500,00</span>
              </div>
              <div className="flex justify-between">
                <span style={{ color: '#8EA0B5' }}>Total Devolvido:</span>
                <span className="font-semibold" style={{ color: '#EF4444' }}>R$ 3.200,00</span>
              </div>
              <div className="flex justify-between">
                <span style={{ color: '#8EA0B5' }}>Total Pago:</span>
                <span className="font-semibold" style={{ color: '#3BA3FF' }}>R$ 8.000,00</span>
              </div>
              <div className="h-px my-2" style={{ backgroundColor: '#20283A' }} />
              <div className="flex justify-between">
                <span style={{ color: '#E7EEF6' }} className="font-semibold">Saldo Pendente:</span>
                <span className="font-bold text-lg" style={{ color: '#F59E0B' }}>R$ 1.300,00</span>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setModalFechar(false)}>
              Cancelar
            </Button>
            <Button onClick={() => {
              toast.success("Consignação fechada com sucesso");
              setModalFechar(false);
            }} className="bg-primary hover:bg-primary/90">
              Confirmar Fechamento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Acertos;