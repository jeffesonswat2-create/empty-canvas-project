import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Plus, Eye, Printer } from "lucide-react";
import { toast } from "sonner";

interface Envio {
  id: string;
  numero: string;
  cliente: string;
  produto: string;
  quantidade: number;
  data: string;
  usuario: string;
}

const Envios = () => {
  const [modalAberto, setModalAberto] = useState(false);
  const [envios] = useState<Envio[]>([
    {
      id: "1",
      numero: "ENV-2025-001",
      cliente: "Livraria Central LTDA",
      produto: "Livro Educativo Vol. 1",
      quantidade: 100,
      data: "2025-01-15",
      usuario: "Admin"
    },
    {
      id: "2",
      numero: "ENV-2025-002",
      cliente: "Papelaria São Paulo",
      produto: "Caderno Universitário",
      quantidade: 150,
      data: "2025-01-16",
      usuario: "Gerente"
    }
  ]);

  const handleNovoEnvio = () => {
    toast.success("Envio registrado com sucesso");
    setModalAberto(false);
  };

  return (
    <div className="flex-1 flex flex-col w-full">
      <main className="flex-1 p-6 space-y-6 overflow-auto" style={{ backgroundColor: '#0F1115' }}>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold" style={{ color: '#3BA3FF' }}>
              Envios
            </h1>
            <p className="text-sm mt-1" style={{ color: '#8EA0B5' }}>
              Registre e gerencie envios de produtos em consignação
            </p>
          </div>
          <Button onClick={() => setModalAberto(true)} className="bg-primary hover:bg-primary/90">
            <Plus className="h-4 w-4 mr-2" />
            Novo Envio
          </Button>
        </div>

        <Card style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <CardHeader>
            <CardTitle style={{ color: '#E7EEF6' }}>Envios Realizados</CardTitle>
            <CardDescription style={{ color: '#8EA0B5' }}>
              {envios.length} envios registrados
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow style={{ borderColor: '#20283A' }}>
                    <TableHead style={{ color: '#8EA0B5' }}>Número</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Cliente</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Produto</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Quantidade</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Data</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Usuário</TableHead>
                    <TableHead style={{ color: '#8EA0B5' }}>Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {envios.map((envio) => (
                    <TableRow key={envio.id} style={{ borderColor: '#20283A' }}>
                      <TableCell style={{ color: '#E7EEF6' }} className="font-mono">{envio.numero}</TableCell>
                      <TableCell style={{ color: '#E7EEF6' }}>{envio.cliente}</TableCell>
                      <TableCell style={{ color: '#E7EEF6' }}>{envio.produto}</TableCell>
                      <TableCell style={{ color: '#3BA3FF' }}>{envio.quantidade}</TableCell>
                      <TableCell style={{ color: '#8EA0B5' }}>{new Date(envio.data).toLocaleDateString('pt-BR')}</TableCell>
                      <TableCell style={{ color: '#8EA0B5' }}>{envio.usuario}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => toast.info("Visualizando comprovante...")}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => toast.info("Imprimindo comprovante...")}
                          >
                            <Printer className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Modal Novo Envio */}
      <Dialog open={modalAberto} onOpenChange={setModalAberto}>
        <DialogContent className="max-w-2xl" style={{ backgroundColor: '#151924', borderColor: '#20283A' }}>
          <DialogHeader>
            <DialogTitle style={{ color: '#E7EEF6' }}>Registrar Novo Envio</DialogTitle>
            <DialogDescription style={{ color: '#8EA0B5' }}>
              Preencha os dados do envio de consignação
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Cliente</Label>
                <Select>
                  <SelectTrigger style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}>
                    <SelectValue placeholder="Selecione o cliente" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="livraria-central">Livraria Central LTDA</SelectItem>
                    <SelectItem value="papelaria-sp">Papelaria São Paulo</SelectItem>
                    <SelectItem value="distribuidora-abc">Distribuidora ABC</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Produto</Label>
                <Select>
                  <SelectTrigger style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}>
                    <SelectValue placeholder="Selecione o produto" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="livro-1">Livro Educativo Vol. 1</SelectItem>
                    <SelectItem value="caderno">Caderno Universitário</SelectItem>
                    <SelectItem value="kit-escolar">Kit Material Escolar</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Quantidade</Label>
                <Input
                  type="number"
                  placeholder="0"
                  style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}
                />
              </div>

              <div className="space-y-2">
                <Label style={{ color: '#E7EEF6' }}>Data do Envio</Label>
                <Input
                  type="date"
                  style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label style={{ color: '#E7EEF6' }}>Observações</Label>
              <Textarea
                placeholder="Observações sobre o envio..."
                style={{ backgroundColor: '#0F1115', borderColor: '#20283A', color: '#E7EEF6' }}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setModalAberto(false)}>
              Cancelar
            </Button>
            <Button onClick={handleNovoEnvio} className="bg-primary hover:bg-primary/90">
              Registrar Envio
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Envios;